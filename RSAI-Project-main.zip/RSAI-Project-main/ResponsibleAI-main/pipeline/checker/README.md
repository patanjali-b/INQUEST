# Checker Script

1. The Model we are using is:


2. Instruction to use:
    refchecker-cli check --input_path /data/circulars/DATA/CircularsGPT/pure_language/RefChecker/alpaca_7b_checker.json --output_path alpaca_7b_checker_final.json --checker_name nli --aggregator_name strict